

class NotFoundError(Exception):
    pass


class BadRequestError(Exception):
    pass


class NotTrainedError(Exception):
    pass

